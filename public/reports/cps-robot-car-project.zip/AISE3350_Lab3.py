from ultrasonic import Ultrasonic
from motor import Ordinary_Car
from servo import Servo
from infrared import Infrared
from adc import ADC
import time
from buzzer import Buzzer
from led import Led

class Car:
    def __init__(self):
        print("Car __init__ starting")
        self.last_turn = 1
        self.buzzer = None
        self.led = Led()

        self.servo = None
        self.sonic = None
        self.motor = None
        self.infrared = None
        self.adc = None
        self.car_record_time = time.time()
        self.car_sonic_servo_angle = 30
        self.car_sonic_servo_dir = 1
        self.car_sonic_distance = [30, 30, 30]
        self.time_compensate = 3
        self.start()
        print("Car __init__ finished")

    def start(self):
        self.servo = self.servo or Servo()
        self.sonic = self.sonic or Ultrasonic()
        self.motor = self.motor or Ordinary_Car()
        self.infrared = self.infrared or Infrared()
        self.adc = self.adc or ADC()
        self.buzzer = self.buzzer or Buzzer()
        print("Hardware objects created")

    def close(self):
        print("Closing car...")
        try:
            if self.motor is not None:
                self.motor.set_motor_model(0, 0, 0, 0)
                self.motor.close()
        except Exception as e:
            print("Error closing motor:", e)

        try:
            if self.sonic is not None:
                self.sonic.close()
        except Exception as e:
            print("Error closing sonic:", e)

        try:
            if self.infrared is not None:
                self.infrared.close()
        except Exception as e:
            print("Error closing infrared:", e)

        try:
            if self.adc is not None:
                self.adc.close_i2c()
        except Exception as e:
            print("Error closing adc:", e)

        try:
            if self.buzzer is not None:
                self.buzzer.close()
        except Exception as e:
            print("Error closing buzzer:", e)

        self.servo = None
        self.sonic = None
        self.motor = None
        self.infrared = None
        self.adc = None
        self.buzzer = None

        self.led.colorBlink(0)
        print("Car closed cleanly")

    def mode_infrared(self):
        # run this body at most 5 times per second
        if 1==1:
            self.car_record_time = time.time()

            # ---------- MOTOR SPEEDS ----------
            A = 600   # turning power
            B = 600   # stronger wheel pair for turns
            C = 600   # straight speed

            # ---------- READ INFRARED SENSORS ----------
            # If your kit is reversed (1 on white / 0 on black), we can flip this later.
            ir1 = self.infrared.read_one_infrared(1)   # left
            ir2 = self.infrared.read_one_infrared(2)   # middle
            ir3 = self.infrared.read_one_infrared(3)   # right

            # Debug IR print
            print("IR:", ir1, ir2, ir3)

            # ---------- LED INDEXES ----------
            global led1, led2, led3, led4, led5, led6, led7, led8
            led1 = 0x01
            led2 = 0x02
            led3 = 0x04
            led4 = 0x08
            led5 = 0x10
            led6 = 0x20
            led7 = 0x40
            led8 = 0x80

            # Default LEDs green (OK state)
            for led in (led1, led2, led3, led4, led5, led6, led7, led8):
                self.led.ledIndex(led, 0, 255, 0)

            # ---------- LINE-FOLLOWING LOGIC ----------
            # Assume: 1 = black (line), 0 = white (background)
            if ir1 == 0 and ir2 == 1 and ir3 == 0:
                direction = 0          # centered
            elif (ir1 == 0 and ir2 == 0 and ir3 == 1) or (ir1 == 0 and ir2 == 1 and ir3 == 1):
                direction = 1          # drifted right
            elif (ir1 == 1 and ir2 == 0 and ir3 == 0) or (ir1 == 1 and ir2 == 1 and ir3 == 0):
                direction = -1         # drifted left
            elif ir1 == 1 and ir2 == 1 and ir3 == 1:
                direction = 2          # junction
            else:
                direction = 3          # lost line

            print("Direction:", direction)

            # ---------- APPLY MOTOR COMMANDS FROM IR ----------
            if direction == 0:
                # straight
                self.motor.set_motor_model(C, C, C, C)
            elif direction == 1:
                # turn right
                self.motor.set_motor_model(A, A, -B, -B)
            elif direction == -1:
                # turn left
                self.motor.set_motor_model(-B, -B, A, A)
            elif direction == 2:
                # junction: use last_turn
                self.motor.set_motor_model(0, 0, 0, 0)
                LF, LR, RF, RR = choosePath(self, A, B, C)
                self.motor.set_motor_model(LF, LR, RF, RR)
            else:
                # lost line: slowly reverse
                self.motor.set_motor_model(C, -C, -C, -C)

            # ---------- SIMPLE ULTRASONIC OBSTACLE CHECK ----------
            # This matches your working test_Ultrasonic style: one distance value.
            distance = self.sonic.get_distance()
            print("Distance:", distance)

            # choose your threshold (cm); try 30 first
            if distance is not None and 0 < distance < 30:
                # Stop and show red LEDs
                self.motor.set_motor_model(0, 0, 0, 0)
                for led in (led1, led2, led3, led4, led5, led6, led7, led8):
                    self.led.ledIndex(led, 255, 0, 0)

                # Beep briefly
                self.buzzer.set_state(True)
                time.sleep(0.3)
                self.buzzer.set_state()

                # Back up a bit
                self.motor.set_motor_model(-C, -C, -C, -C)
                time.sleep(0.4)

                # Turn right a bit to try to go around
                self.motor.set_motor_model(A, A, -B, -B)
                time.sleep(0.4)

                # Then stop again and let the next loop iteration decide what to do
                self.motor.set_motor_model(0, 0, 0, 0)

            

def choosePath(self, A, B, C):
    # when a path must be chosen do the opposite of the last turn and make sure to signal!
    global led1, led2, led3, led4, led5, led6, led7, led8
    if self.last_turn == 1:

        self.led.ledIndex(led1, 0, 0, 255)
        self.led.ledIndex(led2, 0, 0, 255)
        self.led.ledIndex(led3, 0, 0, 255)
        self.led.ledIndex(led4, 0, 0, 255)

        LF = A
        LR = A
        RF = B
        RR = B
        self.last_turn = -1
        return LF, LR, RF, RR

    elif self.last_turn == -1:

        self.led.ledIndex(led5, 0, 0, 255)
        self.led.ledIndex(led6, 0, 0, 255)
        self.led.ledIndex(led7, 0, 0, 255)
        self.led.ledIndex(led8, 0, 0, 255)

        LF = B
        LR = B
        RF = -A
        RR = -A
        self.last_turn = 1
        return LF, LR, RF, RR

    else:
        return -C, -C, -C, -C

def test_car_infrared():
    print("test_car_infrared starting")
    car = Car()
    try:
        while True:
            car.mode_infrared()
    except KeyboardInterrupt:
        car.close()
        print("\nEnd of program")
    except Exception as e:
        print("ERROR in test_car_infrared:", e)
        car.close()

if __name__ == '__main__':
    print("Lab3 main starting (no parameters required)")
    test_car_infrared()
